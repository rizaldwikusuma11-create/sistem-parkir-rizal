[app]
title = Sistem Parkir Rizal
package.name = sistemparkirrizal
package.domain = org.smkn3boyolangu
source.dir = .
source.include_exts = py,json,png,jpg,kv,atlas
version = 1.0.0
requirements = python3,kivy,plyer,pillow
orientation = portrait
fullscreen = 0
android.permissions = CAMERA
android.api = 33
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
