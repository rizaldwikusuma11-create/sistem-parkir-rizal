# APLIKASI PARKIR SMKN 3 BOYOLANGU
# GUI Kivy untuk Pydroid 3 (Android)
# Instal Kivy dari menu Pip / Quick Install di Pydroid 3 jika belum tersedia.

import json
import os
from datetime import datetime
import re

from kivy.clock import Clock

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.graphics import Color, RoundedRectangle

BG = (0.025, 0.035, 0.075, 1)       # hitam kebiruan
HEADER = (0.055, 0.085, 0.19, 1)
PANEL = (0.075, 0.11, 0.23, 1)
BLUE = (0.10, 0.38, 0.90, 1)        # hanya tombol/menu aktif
BLACK = (0.012, 0.018, 0.04, 1)     # menu tidak aktif
GREEN = (0.02, 0.68, 0.53, 1)
WHITE = (0.96, 0.97, 1, 1)
MUTED = (0.74, 0.80, 0.91, 1)

IDENTITY = "Rizal Dwi Kusuma X TE 3"
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "data_parkir_smkn3.json")


def now_text():
    return datetime.now().strftime("%d-%m-%Y %H:%M:%S")


def add_bg(widget, color, radius=10):
    with widget.canvas.before:
        Color(*color)
        rect = RoundedRectangle(pos=widget.pos, size=widget.size,
                                radius=[dp(radius)])
    widget.bind(pos=lambda obj, val: setattr(rect, "pos", val),
                size=lambda obj, val: setattr(rect, "size", val))
    return rect


class ParkingApp(App):
    def build(self):
        self.title = "Parkir SMKN 3 Boyolangu"
        self.records = self.load_data()
        self.sm = ScreenManager()
        self.sm.add_widget(HomeScreen(name="home", app=self))
        self.sm.add_widget(ParkingScreen(name="parking", app=self))
        self.sm.add_widget(DataScreen(name="data", app=self))
        self.sm.bind(current=self.update_navigation)
        return self.sm

    def load_data(self):
        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data if isinstance(data, list) else []
        except Exception:
            pass
        return []

    def save_data(self):
        try:
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(self.records, f, ensure_ascii=False, indent=2)
        except Exception as exc:
            self.message("Gagal menyimpan", str(exc))

    def active_records(self):
        return [r for r in self.records if r.get("active")]

    def message(self, title, message):
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        box.add_widget(Label(text=message, color=WHITE, halign="center"))
        popup = Popup(title=title, content=box, size_hint=(0.86, 0.34))
        ok = Button(text="OK", size_hint_y=None, height=dp(44),
                    background_normal="", background_color=BLUE)
        ok.bind(on_release=popup.dismiss)
        box.add_widget(ok)
        popup.open()

    def go(self, name):
        self.sm.current = name
        screen = self.sm.get_screen(name)
        if hasattr(screen, "refresh"):
            screen.refresh()

    def update_navigation(self, *_):
        # Saat aplikasi baru dibuat, beberapa halaman mungkin belum
        # dimasukkan ke ScreenManager. Lewati halaman yang belum tersedia.
        for name in ("home", "parking", "data"):
            if not self.sm.has_screen(name):
                continue
            screen = self.sm.get_screen(name)
            if hasattr(screen, "nav_buttons"):
                for key, btn in screen.nav_buttons.items():
                    btn.background_color = BLUE if key == self.sm.current else BLACK


class BaseScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app
        self.nav_buttons = {}
        self.root_box = BoxLayout(orientation="vertical", spacing=dp(8),
                                  padding=[dp(12), dp(10), dp(12), dp(8)])
        add_bg(self.root_box, BG, 0)
        self.add_widget(self.root_box)

    def header(self):
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        height=dp(66), padding=[dp(12), dp(7)], spacing=dp(3))
        add_bg(box, HEADER, 10)
        name = Label(text=IDENTITY, color=WHITE, bold=True, font_size="17sp",
                     halign="center", valign="middle", size_hint_y=0.58)
        sub = Label(text="SISTEM INFORMASI PARKIR | SMKN 3 BOYOLANGU",
                    color=MUTED, font_size="11sp", halign="center",
                    valign="middle", size_hint_y=0.42)
        box.add_widget(name)
        box.add_widget(sub)
        return box

    def page_title(self, title, subtitle):
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        height=dp(76), spacing=dp(3))
        box.add_widget(Label(text=title, color=WHITE, bold=True,
                             font_size="23sp", halign="left",
                             valign="middle", size_hint_y=0.58))
        box.add_widget(Label(text=subtitle, color=MUTED, font_size="13sp",
                             halign="left", valign="middle", size_hint_y=0.42))
        return box

    def card(self, parent, padding=12, spacing=8):
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        padding=dp(padding), spacing=dp(spacing))
        box.bind(minimum_height=box.setter("height"))
        add_bg(box, PANEL, 10)
        parent.add_widget(box)
        return box

    def label(self, text, size=14, color=WHITE, bold=False, height=26,
              halign="left"):
        return Label(text=text, color=color, bold=bold, font_size=f"{size}sp",
                     halign=halign, valign="middle",
                     size_hint_y=None, height=dp(height),
                     text_size=(None, None))

    def button(self, text, callback, color=BLUE, height=46):
        btn = Button(text=text, size_hint_y=None, height=dp(height),
                     background_normal="", background_down="",
                     background_color=color, color=WHITE,
                     bold=True, font_size="14sp")
        btn.bind(on_release=lambda *_: callback())
        return btn

    def navigation(self):
        nav = GridLayout(cols=3, spacing=dp(6), size_hint_y=None,
                         height=dp(48))
        items = [("home", "BERANDA"), ("parking", "PARKIR"),
                 ("data", "DATA")]
        for key, caption in items:
            btn = self.button(caption,
                              lambda selected=key: self.app_ref.go(selected),
                              BLACK, 48)
            self.nav_buttons[key] = btn
            nav.add_widget(btn)
        self.app_ref.update_navigation()
        return nav

    def page_frame(self, title, subtitle):
        self.root_box.clear_widgets()
        self.nav_buttons = {}
        self.root_box.add_widget(self.header())
        self.root_box.add_widget(self.page_title(title, subtitle))

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        self.body = BoxLayout(orientation="vertical", spacing=dp(10),
                              size_hint_y=None, padding=[0, dp(2), 0, dp(12)])
        self.body.bind(minimum_height=self.body.setter("height"))
        scroll.add_widget(self.body)
        self.root_box.add_widget(scroll)

        footer = BoxLayout(orientation="vertical", size_hint_y=None,
                           height=dp(83), spacing=dp(5))
        footer.add_widget(Label(text=IDENTITY, color=MUTED,
                                font_size="11sp", size_hint_y=None,
                                height=dp(25)))
        footer.add_widget(self.navigation())
        self.root_box.add_widget(footer)
        self.app_ref.update_navigation()
        return self.body


class HomeScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)
        self.refresh()

    def refresh(self):
        body = self.page_frame("Parkir sekolah, lebih tertata.",
                               "Pencatatan kendaraan SMKN 3 Boyolangu dalam satu aplikasi.")
        active = self.app_ref.active_records()

        hero = self.card(body, 14, 7)
        hero.add_widget(self.label("SMKN 3 BOYOLANGU", 14, bold=True,
                                   height=28, halign="center"))
        hero.add_widget(self.label("Kelola parkir", 22, bold=True,
                                   height=38, halign="center"))
        hero.add_widget(self.label(f"{len(active)} kendaraan sedang parkir",
                                   14, MUTED, height=28, halign="center"))
        hero.add_widget(self.button("KELOLA PARKIR",
                                    lambda: self.app_ref.go("parking")))

        body.add_widget(self.label("Area parkir", 18, bold=True, height=34))
        row = GridLayout(cols=2, spacing=dp(8), size_hint_y=None,
                         height=dp(94))
        for category, color in (("Guru", GREEN), ("Murid", BLUE)):
            count = sum(1 for r in active if r.get("category") == category)
            item = BoxLayout(orientation="vertical", padding=dp(9),
                             spacing=dp(2))
            add_bg(item, PANEL, 9)
            item.add_widget(self.label(f"Parkiran {category}", 14,
                                       bold=True, height=28, halign="center"))
            item.add_widget(self.label(f"{count} kendaraan aktif", 12,
                                       MUTED, height=24, halign="center"))
            row.add_widget(item)
        body.add_widget(row)

        quick = self.card(body)
        quick.add_widget(self.label("Akses cepat", 18, bold=True, height=30))
        quick.add_widget(self.button("KENDARAAN MASUK",
                                     lambda: self.app_ref.go("parking")))
        quick.add_widget(self.button("LIHAT DATA PARKIR",
                                     lambda: self.app_ref.go("data"), GREEN))


class ParkingScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)
        self.refresh()

    def refresh(self):
        body = self.page_frame("Parkir", "Pilih proses sesuai arah kendaraan.")
        entry = self.card(body)
        entry.add_widget(self.label("Kendaraan masuk", 18, bold=True, height=30))
        self.plate = TextInput(hint_text="Nomor plat, contoh AG 1234 ABC",
                               multiline=False, size_hint_y=None, height=dp(45))
        entry.add_widget(self.plate)
        entry.add_widget(self.button("SCAN PLAT DENGAN KAMERA HP",
                                     self.scan_plate, GREEN, 48))
        entry.add_widget(self.label(
            "Arahkan kamera ke plat nomor dengan cahaya cukup. "
            "Hasil scan akan dimasukkan ke kolom plat untuk diperiksa.",
            11, MUTED, height=38))
        self.kind = Spinner(text="Sepeda motor",
                            values=("Sepeda motor", "Mobil", "Sepeda"),
                            size_hint_y=None, height=dp(44))
        entry.add_widget(self.kind)
        self.category = Spinner(text="Guru", values=("Guru", "Murid"),
                                size_hint_y=None, height=dp(44))
        entry.add_widget(self.category)
        self.owner = TextInput(hint_text="Nama pemilik (opsional)",
                               multiline=False, size_hint_y=None, height=dp(45))
        entry.add_widget(self.owner)
        entry.add_widget(self.button("SIMPAN KENDARAAN MASUK",
                                     self.vehicle_entry))

        exit_card = self.card(body)
        exit_card.add_widget(self.label("Kendaraan keluar", 18,
                                        bold=True, height=30))
        active = self.app_ref.active_records()
        options = [f"{r['plate']} | {r['category']}" for r in active]
        self.exit_spinner = Spinner(
            text=options[0] if options else "Tidak ada kendaraan aktif",
            values=options, size_hint_y=None, height=dp(44))
        exit_card.add_widget(self.exit_spinner)
        exit_card.add_widget(self.button("KONFIRMASI KELUAR",
                                         self.vehicle_exit, GREEN))
        exit_card.add_widget(self.label(
            "Waktu masuk dan keluar dicatat otomatis dari jam perangkat.",
            11, MUTED, height=34))

    def scan_plate(self):
        """Buka kamera HP melalui aplikasi kamera Android (jika Plyer tersedia)."""
        try:
            from plyer import camera
        except Exception:
            self.app_ref.message(
                "Kamera belum tersedia",
                "Modul kamera HP belum terpasang. Di Pydroid 3, buka Pip "
                "lalu instal 'plyer'. Setelah itu izinkan akses Kamera "
                "pada Pengaturan Android."
            )
            return

        try:
            folder = self.app_ref.user_data_dir
            os.makedirs(folder, exist_ok=True)
            filename = os.path.join(
                folder, f"foto_plat_{int(datetime.now().timestamp())}.jpg"
            )

            # Meminta izin kamera Android bila API permission tersedia.
            try:
                from android.permissions import request_permissions, Permission
                request_permissions([Permission.CAMERA])
            except Exception:
                pass

            camera.take_picture(
                filename=filename,
                on_complete=lambda path: Clock.schedule_once(
                    lambda dt: self.process_plate_photo(path), 0
                )
            )
        except Exception as exc:
            self.app_ref.message(
                "Kamera gagal dibuka",
                "Pastikan izin kamera untuk Pydroid 3 sudah diaktifkan. "
                f"Detail: {exc}"
            )

    def process_plate_photo(self, photo_path):
        """Coba membaca tulisan plat dari foto; jika OCR tidak ada, tetap simpan foto."""
        if not photo_path or not os.path.exists(photo_path):
            self.app_ref.message("Foto tidak ditemukan",
                                 "Pengambilan foto dibatalkan atau gagal.")
            return

        try:
            from PIL import Image, ImageOps, ImageEnhance
            import pytesseract

            image = Image.open(photo_path).convert("L")
            image = ImageOps.autocontrast(image)
            image = ImageEnhance.Contrast(image).enhance(2.0)
            text = pytesseract.image_to_string(
                image, config="--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "
            )
            compact = re.sub(r"[^A-Z0-9]", "", text.upper())

            # Pola umum plat Indonesia: 1-2 huruf, 1-4 angka, 1-3 huruf.
            match = re.search(r"([A-Z]{1,2})([0-9]{1,4})([A-Z]{1,3})", compact)
            if match:
                plate = f"{match.group(1)} {match.group(2)} {match.group(3)}"
                self.plate.text = plate
                self.app_ref.message(
                    "Plat terbaca",
                    f"Hasil pembacaan kamera: {plate}. Periksa kembali "
                    "hasilnya sebelum menekan tombol simpan."
                )
            else:
                self.app_ref.message(
                    "Plat belum terbaca",
                    "Foto berhasil diambil, tetapi tulisan plat belum dikenali. "
                    "Coba foto lebih dekat, lurus, dan terang, atau ketik plat secara manual."
                )
        except Exception as exc:
            self.app_ref.message(
                "Foto berhasil diambil",
                "Kamera HP berhasil digunakan, tetapi fitur pembaca teks (OCR) "
                "belum siap di perangkat ini. Untuk membaca plat otomatis "
                "diperlukan Tesseract OCR yang kompatibel dengan Android/Pydroid. "
                "Sementara itu, ketik nomor plat pada kolom secara manual. "
                f"Detail: {exc}"
            )

    def vehicle_entry(self):
        plate = self.plate.text.strip().upper()
        if not plate:
            self.app_ref.message("Peringatan", "Nomor plat kendaraan harus diisi.")
            return
        owner = self.owner.text.strip()

        # Samakan format plat agar "AG 1234 ABC" dan "AG1234ABC"
        # dianggap sebagai plat yang sama.
        normalized_plate = "".join(ch for ch in plate if ch.isalnum()).upper()
        normalized_owner = " ".join(owner.casefold().split())

        # Cegah plat atau nama yang sama masuk dua kali selama masih aktif.
        for existing in self.app_ref.records:
            if not existing.get("active"):
                continue

            existing_plate = "".join(
                ch for ch in existing.get("plate", "") if ch.isalnum()
            ).upper()
            existing_owner = " ".join(
                existing.get("owner", "").casefold().split()
            )

            if existing_plate == normalized_plate:
                self.app_ref.message(
                    "Kendaraan Ditolak",
                    f"Plat {plate} sudah terdaftar dan masih berada di parkiran."
                )
                return

            if normalized_owner and existing_owner == normalized_owner:
                self.app_ref.message(
                    "Nama Ditolak",
                    f"Nama {owner} sudah terdaftar sebagai kendaraan yang masih parkir."
                )
                return

        record = {
            "id": int(datetime.now().timestamp() * 1000),
            "plate": plate, "kind": self.kind.text,
            "category": self.category.text, "owner": owner,
            "entry": now_text(), "exit": "", "active": True
        }
        self.app_ref.records.insert(0, record)
        self.app_ref.save_data()
        self.app_ref.message("Berhasil",
                             f"{plate} masuk ke parkiran {record['category']}.")
        self.refresh()

    def vehicle_exit(self):
        selected = self.exit_spinner.text
        if selected == "Tidak ada kendaraan aktif":
            self.app_ref.message("Informasi", "Tidak ada kendaraan yang dipilih.")
            return
        plate = selected.split(" | ")[0]
        for record in self.app_ref.records:
            if record.get("active") and record.get("plate") == plate:
                record["active"] = False
                record["exit"] = now_text()
                self.app_ref.save_data()
                self.app_ref.message("Berhasil",
                                     f"Kendaraan {plate} berhasil dicatat keluar.")
                self.refresh()
                return


class DataScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)
        self.refresh()

    def refresh(self):
        body = self.page_frame("Data parkir",
                               "Lihat kendaraan yang masih berada di sekolah dan riwayat.")
        active = self.app_ref.active_records()
        guru = sum(1 for r in active if r.get("category") == "Guru")
        murid = sum(1 for r in active if r.get("category") == "Murid")

        summary = self.card(body)
        summary.add_widget(self.label("SEDANG BERADA DI SEKOLAH", 12,
                                      MUTED, bold=True, height=24))
        summary.add_widget(self.label(f"{len(active)} kendaraan", 23,
                                      bold=True, height=38))
        summary.add_widget(self.label(
            f"Parkiran Guru: {guru}  |  Parkiran Murid: {murid}",
            12, MUTED, height=26))

        body.add_widget(self.label("Kendaraan sedang parkir", 17,
                                   bold=True, height=34))
        if active:
            for record in active:
                self.record_card(body, record, True)
        else:
            empty = self.card(body)
            empty.add_widget(self.label("Belum ada kendaraan yang sedang parkir.",
                                        13, MUTED, height=30))

        body.add_widget(self.label("Riwayat parkir", 17, bold=True, height=34))
        history = [r for r in self.app_ref.records if not r.get("active")]
        if history:
            for record in history:
                self.record_card(body, record, False)
        else:
            empty = self.card(body)
            empty.add_widget(self.label("Belum ada riwayat kendaraan keluar.",
                                        13, MUTED, height=30))

    def record_card(self, parent, record, active):
        box = self.card(parent, 11, 4)
        box.add_widget(self.label(
            f"{record.get('plate', '-')} | Parkiran {record.get('category', '-')}",
            14, bold=True, height=26))
        box.add_widget(self.label(f"Jenis: {record.get('kind', '-')}",
                                  12, MUTED, height=22))
        if record.get("owner"):
            box.add_widget(self.label(f"Pemilik: {record['owner']}",
                                      12, MUTED, height=22))
        box.add_widget(self.label(f"Masuk: {record.get('entry', '-')}",
                                  11, MUTED, height=22))
        if not active:
            box.add_widget(self.label(f"Keluar: {record.get('exit', '-')}",
                                      11, MUTED, height=22))


if __name__ == "__main__":
    ParkingApp().run()
